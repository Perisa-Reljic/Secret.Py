#!/usr/bin/env python3
# ==========================================
# Title: Let me Script You: Secret
# Author: Perisa Reljic [ ▽ Ш ]
# ==========================================

import sys
import os
import random
import base64
import hashlib
import subprocess
from getpass import getpass

# ------------------------------------------
# 1. PASSWORD GENERATOR
# ------------------------------------------
def generate_password(length=16):
    """Generates a secure random password of specified length."""
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?"
    return "".join(random.choice(chars) for _ in range(length))

# ------------------------------------------
# 2. KEY DERIVATION (PBKDF2)
# ------------------------------------------
def derive_key(passphrase: str, salt: bytes) -> bytes:
    """Derives a cryptographic key from the master passphrase using salt."""
    return hashlib.pbkdf2_hmac('sha256', passphrase.encode('utf-8'), salt, 100_000)

# ------------------------------------------
# 3. TEXT ENCRYPTION
# ------------------------------------------
def simple_encrypt(plain_text: str, passphrase: str) -> str:
    """Encrypts plain text using XOR logic and a passphrase-derived key."""
    salt = os.urandom(16)
    key = derive_key(passphrase, salt)
    
    data = plain_text.encode('utf-8')
    encrypted = bytearray(b ^ key[i % len(key)] for i, b in enumerate(data))
    
    combined = salt + bytes(encrypted)
    return base64.b64encode(combined).decode('utf-8')

# ------------------------------------------
# 4. TEXT DECRYPTION
# ------------------------------------------
def simple_decrypt(cipher_base64: str, passphrase: str) -> str:
    """Decrypts a Base64 cipher string back to plain text using the master passphrase."""
    try:
        combined = base64.b64decode(cipher_base64.encode('utf-8'))
        salt = combined[:16]
        encrypted = combined[16:]
        
        key = derive_key(passphrase, salt)
        decrypted = bytearray(b ^ key[i % len(key)] for i, b in enumerate(encrypted))
        return decrypted.decode('utf-8')
    except Exception:
        return "[Error]: Decryption failed (wrong passphrase or invalid format)!"

# ------------------------------------------
# 5. CLIPBOARD HANDLING (Xclip / Xsel)
# ------------------------------------------
def get_clipboard() -> str:
    """Reads text from the system clipboard on Linux."""
    try:
        p = subprocess.run(['xclip', '-selection', 'clipboard', '-o'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if p.returncode == 0:
            return p.stdout
    except FileNotFoundError:
        pass
    
    try:
        p = subprocess.run(['xsel', '--clipboard', '--output'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if p.returncode == 0:
            return p.stdout
    except FileNotFoundError:
        pass
        
    print("[Error]: Neither 'xclip' nor 'xsel' found. Install via: sudo apt install xclip")
    sys.exit(1)

def set_clipboard(text: str):
    """Copies given text to the system clipboard."""
    try:
        subprocess.run(['xclip', '-selection', 'clipboard'], input=text, text=True, check=True)
        return
    except FileNotFoundError:
        pass
        
    try:
        subprocess.run(['xsel', '--clipboard', '--input'], input=text, text=True, check=True)
        return
    except FileNotFoundError:
        print("[Error]: Unable to copy to clipboard (missing xclip/xsel).")

# ------------------------------------------
# 6. FILE ENCRYPTION & DECRYPTION
# ------------------------------------------
def encrypt_file(input_file: str, output_file: str, passphrase: str):
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()
        cipher = simple_encrypt(content, passphrase)
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(cipher)
        print(f"[Success]: File '{input_file}' successfully encrypted into '{output_file}'.")
    except Exception as e:
        print(f"[Error]: Failed to encrypt file -> {e}")

def decrypt_file(input_file: str, output_file: str, passphrase: str):
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            cipher = f.read().strip()
        plain = simple_decrypt(cipher, passphrase)
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(plain)
        print(f"[Success]: File '{input_file}' successfully decrypted into '{output_file}'.")
    except Exception as e:
        print(f"[Error]: Failed to decrypt file -> {e}")

# ------------------------------------------
# 7. MAIN MENU & CLI ARGUMENT PARSER
# ------------------------------------------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("==================================================")
        print("  Let me Script You: Secret | Author: Perisa Reljic [ ▽ Ш ]")
        print("==================================================")
        print("Usage:")
        print("  python3 secret.py gen [length]          - Generate a strong password")
        print("  python3 secret.py enc                   - Encrypt text from terminal prompt")
        print("  python3 secret.py dec                   - Decrypt text from terminal prompt")
        print("  python3 secret.py fenc <in> <out>       - Encrypt a text file")
        print("  python3 secret.py fdec <in> <out>       - Decrypt an encrypted file")
        print("  python3 secret.py clenc                 - Encrypt text directly from CLIPBOARD")
        print("  python3 secret.py cldec                 - Decrypt cipher directly from CLIPBOARD")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "gen":
        length = int(sys.argv[2]) if len(sys.argv) > 2 else 16
        print(f"Generated Password: {generate_password(length)}")

    elif cmd == "enc":
        text = getpass("Enter text to encrypt: ")
        passphrase = getpass("Enter master passphrase: ")
        result = simple_encrypt(text, passphrase)
        print(f"\nEncrypted Result:\n{result}")

    elif cmd == "dec":
        cipher = input("Enter encrypted string: ")
        passphrase = getpass("Enter master passphrase: ")
        result = simple_decrypt(cipher, passphrase)
        print(f"\nDecrypted Result:\n{result}")

    elif cmd == "fenc":
        if len(sys.argv) < 4:
            print("Usage for file: python3 secret.py fenc <input_txt> <output_enc>")
            sys.exit(1)
        passphrase = getpass("Enter master passphrase for file: ")
        encrypt_file(sys.argv[2], sys.argv[3], passphrase)

    elif cmd == "fdec":
        if len(sys.argv) < 4:
            print("Usage for file: python3 secret.py fdec <input_enc> <output_txt>")
            sys.exit(1)
        passphrase = getpass("Enter master passphrase for file: ")
        decrypt_file(sys.argv[2], sys.argv[3], passphrase)

    elif cmd == "clenc":
        text = get_clipboard()
        if not text.strip():
            print("[Error]: Clipboard is empty!")
            sys.exit(1)
        passphrase = getpass("Enter master passphrase for clipboard encryption: ")
        result = simple_encrypt(text, passphrase)
        set_clipboard(result)
        print("[Success]: Clipboard text encrypted and new cipher sent back to clipboard! (Ready to Paste)")

    elif cmd == "cldec":
        cipher = get_clipboard()
        if not cipher.strip():
            print("[Error]: Clipboard is empty!")
            sys.exit(1)
        passphrase = getpass("Enter master passphrase for clipboard decryption: ")
        result = simple_decrypt(cipher.strip(), passphrase)
        set_clipboard(result)
        print("[Success]: Clipboard cipher decrypted and plain text sent back to clipboard! (Ready to Paste)")